export class product{
    constructor(id,name,price,qty,desc,rating,cover){
        this.id=id;
        this.name=name;
        this.price=price;
        this.qty=qty;
        this.desc=desc;
        this.rating=rating;
        this.cover=cover;

    }





}