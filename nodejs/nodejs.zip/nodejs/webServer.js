const http = require('http')
const fs = require('fs')
const dayjs = require('dayjs')

console.log(dayjs().year())
console.log(dayjs().hour()+':'+dayjs().minute())
console.log(dayjs().second())

const server = http.createServer((req,res)=>{{
    console.log('received the request')
    // console.log(req.url)
    // console.log(req.method)
    
    res.setHeader('Content-Type', 'text/html');
    

    //Link
    let path = './page/'
    switch(req.url){
        case'/':
            path +='index.html'
            res.statusCode=200
            break;

        case'/about':
            path +='about.html'
            res.statusCode=200
            break;

        case'/aboutus':
            path +='about.html'
            res.statusCode=301
            res.setHeader('Location','/about')
            res.end()

            break;

        case'/Login':
            path +='Login.html'
           
            res.statusCode=200
            break;


        default:
            path+='404.html'
            res.statusCode=404
            break;
    }



    fs.readFile(path,(error,data)=>{
        if(error){
            console.log('error::'+error)
        }   
        else{
            res.write(data)
            res.end()
        }
            
    })
    fs.readFile('./page/Login.css',(error,data)=>{
        if(error){
            console.log('error::'+error)
        }   
        else{
            res.writeHead(200,{'Content-Type':'text/css'});
            res.write(data)
            res.end()
        }
            
    })



    // res.write('<h1> Hello </h1>')

}})

server.listen(3001,'localhost',()=>{
    console.log('Server listening the port 3001')
})

