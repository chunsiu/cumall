console.log('this is mmessage')
console.log(__dirname)
console.log(__filename)
