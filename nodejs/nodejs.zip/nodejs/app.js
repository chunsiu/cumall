const express = require('express')
var cors = require('cors')
const dayjs = require('dayjs')
const bodyParser = require ('body-parser');
const registerController = require('./public/registerController')
 
//database
const mysql =require('mysql')
const db = mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'',
    database:'fyp',
    // port:4330
})

db.connect((err)=>{
    if(err){
       throw err
    }else{
        console.log('mysql connected');
    } 
})




// adv:
// more streamlined
const app = express()
app.use(cors())
//database
app.get('/createdb',(req,res)=>{
    let sql='CREATE DATABASE fyp';
    db.query(sql,(err,result)=>{
        if(err) throw err;
        console.log(result);
        res.send('database created');
    })
})

app.get('/fpwd/:id',(req,res)=>{
    let sql=`Select password from user where uid = ${req.params.id}`;
   // let sql = "select password from user"
    db.query(sql,(err,result)=>{
        if(err) throw err;
        console.log(result);
        
      //  res.send(result[0].password);
        res.json(
           result
        );
    })
})

app.get('/login/:uname',(req,res)=>{
    let sql= 'Select password, type from user where userName = "'+req.params.uname+'"';

    db.query(sql,(err,result)=>{
        if(err) throw err;
        console.log(result);

        
      //  res.send(result[0].password);
        res.json(result);
    })

})

app.get('/keyword/:key',(req,res)=>{
     
    let sql = 'select restaurant_name from restaurant r, restaurantkeyword rk where r.restaurant_id=rk.restaurant_id and menu_keywords like "%'+req.params.key+'%"';
    db.query(sql,(err,result)=>{
        if(err) throw err;
        console.log(result);
        
        //res.send(result[0].password);
        res.json(
            result
        );
    })
})

app.get('/upload_menu/:key',(req,res)=>{
     let sql = 'insert into restaurantkeyword values("2","' +   req.params.key+'") '
    
    db.query(sql,(err,result)=>{
        if(err) throw err;
        console.log('data updated');
         
        
        //res.send(result[0].password);
         res.send("updated!");
    })
})





app.use((req,resm,next)=>{
    console.log(`new visitor : come from ${req.hostname} | request new page ${req.path}`)
    next()
})


// use ejs(view engine)
app.set('view engine','ejs')
app.set('views','page')  // page is the html folder
app.use(express.static('public'))
app.get('/',(req,res)=>{
    //res.send('<h1>Home</h1>')
    // res.sendFile('./page/index.html',{root__dirname})   


    let page =[
        {title:'1', author:'tom1'},
        {title:'2', author:'tom2'},
        {title:'3', author:'tom3'},
    ]
    let now = `now: ${dayjs().hour()+':'+dayjs().minute()} xxx ${dayjs().second()}s`  // show in index
    res.render('index',{
        Name:'the name',
        time:now,
        pages:page,
        webTitle:'home'
    })
    

})
app.get('/about',(req,res)=>{
    // res.sendFile('./page/about.html',{root__dirname})
    res.render('about',{webTitle:'about'})
})
// app.get('/aboutus',(req,res)=>{
//     res.redirect('/about')
// })


app.use((req,res)=>{
    // 404 method must be in bottom
    // res.status(404).sendFile('./page/404.html',{root:_dirname})
    // res.sendFile('./page/404.html',{root:_dirname})
    // res.status(404)
    res.status(404).render('404')
})

app.get('/register',(req,res)=>{
    let sql = 'insert into restaurantkeyword values("2","' +   req.params.key+'") '
   
    db.query(sql,(err,result)=>{
        if(err) throw err;
        console.log('data updated');
         
        
        //res.send(result[0].password);
         res.send("updated!");
    })

})


app.listen(5500)