// use file system
const fs= require('fs') 

//write
fs.writeFile('./demo.txt','This is information',()=>{
    console.log('finished')
})

//read
fs.readFile('./demo.txt',(error, data)=>{
    if(error){
        console.log(error)
    }
    console.log(data)
    console.log(data.toString())
})

//if error
fs.readFile('./demo222.txt',(error, data)=>{
    if(error){
        console.log(error)
    }else{
        console.log(data)
        console.log(data.toString())
    }
    
})

// create a new folder
fs.mkdir('./image',(error)=>{
    if(error){
        console.log(error)

    }else{
        console.log('created')
    }
})

//delete folder
if(fs.existsSync('./delete.txt')){
    fs.unlink('./delete.txt',(error)=>{
        if(error){
            console.log(error)
    
        }else{
            console.log('Deleted')
        }
    })
}else{
    console.log('No exist')
}
